<?php 

if (isset($_POST['create'])) {
	include "../koneksi.php";
	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$title = validate($_POST['title']);
	$author = validate($_POST['author']);
    $genre = validate($_POST['genre']);

	$user_data = 'title='.$title. '&author='.$author. 'genre='.$genre;

	if (empty($title)) {
		header("Location:addlist.php?error=Title is required&$user_data");
	}else if (empty($author)) {
		header("Location:addlist.php?error=Author is required&$user_data");
    }else if (empty($genre)) {
		header("Location:addlist.php?error=Genre is required&$user_data");
	}else {

       $sql = "INSERT INTO tbl_list (title, author, genre) 
               VALUES('$title', '$author', '$genre')";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location:readlist.php?success=successfully Added");
       }else {
          header("Location:addlist.php?error=unknown error occurred&$user_data");
       }
	}

}