<?php 

if (isset($_GET['id'])) {
	include "../koneksi.php";

	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$id = validate($_GET['id']);

	$sql = "SELECT * FROM tbl_list WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
    	$row = mysqli_fetch_assoc($result);
    }else {
    	header("Location:readlist.php");
    }

}else if(isset($_POST['update'])){
    include "../koneksi.php";
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$title = validate($_POST['title']);
	$author = validate($_POST['author']);
    $genre = validate($_POST['genre']);
	$id = validate($_POST['id']);

	if (empty($title)) {
		header("Location:updatelist.php?id=$id&error=Title is required");
	}else if (empty($author)) {
		header("Location:updatelist.php?id=$id&error=Author is required");
    }else if (empty($genre)) {
		header("Location:updatelist.php?id=$id&error=Genre is required");
	}else {

       $sql = "UPDATE tbl_list
               SET title='$title', author='$author', genre='$genre'
               WHERE id=$id ";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location:readlist.php?success=successfully updated");
       }else {
          header("Location:updatelist.php?id=$id&error=unknown error occurred&$user_data");
       }
	}
}else {
	header("Location:readlist.php");
}