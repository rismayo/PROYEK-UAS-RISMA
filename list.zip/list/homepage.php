<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HOMEPAGE</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Berkshire+Swash&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="design.css">
</head>
<body>
    <div class="banner-text">
        <ul>
            <li><a href="addlist.php">Add List</a></li>            
            <li><a href="readlist.php">Reading List</a></li>                       
        </ul>
        
        <h2>Reading List</h2>
		<p>list your books in here!</p>
    </div>
    
    <div class="animation-area">
        <ul class="box-area">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>	
</body>
</html>
