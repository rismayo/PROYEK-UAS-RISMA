<!DOCTYPE html>
<html>
<head>
	<title>ADD LIST</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<form action="create.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">ADD LIST</h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="title">Title</label>
		     <input type="title" 
		           class="form-control" 
		           id="title" 
		           name="title" 
		           value="<?php if(isset($_GET['title']))
		                           echo($_GET['title']); ?>" 
		           placeholder="Enter title">
		   </div>

		   <div class="form-group">
		     <label for="author">Author</label>
		     <input type="author" 
		           class="form-control" 
		           id="author" 
		           name="author" 
		           value="<?php if(isset($_GET['author']))
		                           echo($_GET['author']); ?>"
		           placeholder="Enter author">
		   </div>

           <div class="form-group">
		     <label for="genre">Genre</label>
		     <input type="genre" 
		           class="form-control" 
		           id="genre" 
		           name="genre" 
		           value="<?php if(isset($_GET['genre']))
		                           echo($_GET['genre']); ?>"
		           placeholder="Enter genre">
		   </div>

		   <button type="submit" 
		          class="btn btn-primary"
		          name="create">Add</button>
		    <a href="readlist.php" class="link-primary">View</a>
	    </form>
	</div>
</body>

</html>