<?php  

include "../koneksi.php";

$sql = "SELECT * FROM tbl_list ORDER BY id DESC";
$result = mysqli_query($conn, $sql);